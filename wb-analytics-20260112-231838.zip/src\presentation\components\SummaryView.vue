<template>
  <div class="space-y-6">
    <!-- Заголовок и фильтры -->
    <div class="flex flex-col gap-4">
      <div class="flex items-center justify-between">
        <h2 class="text-2xl font-bold text-gray-900">Сводка</h2>
      </div>
      <div class="flex items-center gap-3 flex-wrap">
        <!-- Фильтр по артикулам продавца (vendorCode) -->
        <VendorCodeDropdown
          v-model="selectedVendorCodes"
          :options="vendorOptions"
          placeholder="Фильтр по vendor code"
        />
        <!-- Поиск по тексту -->
        <div class="relative">
          <input
            v-model="searchQuery"
            type="text"
            placeholder="Поиск по артикулу, названию..."
            class="px-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent w-80"
          />
          <svg
            v-if="searchQuery"
            @click="searchQuery = ''"
            class="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 cursor-pointer hover:text-gray-600"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </div>
        <PresetsControl
          v-if="!presetsLoading"
          :presets="presets"
          :active-preset-id="activePresetId"
          :is-dirty="isDirty"
          @select="handlePresetSelect"
          @save="handlePresetSave"
          @save-as="handlePresetSaveAs"
          @rename="handlePresetRename"
          @delete="handlePresetDelete"
        />
        <ColumnsPickerDropdown
          :all-columns="summaryColumns"
          :visible-column-ids="visibleColumnIds"
          :column-order="columnOrder"
          @update:visible-column-ids="applyVisible"
          @reset="resetToDefault"
          @open-reorder-modal="handleReorderModalOpen"
        />
        <ColumnReorderModal
          :is-open="isReorderModalOpen"
          :all-columns="summaryColumns"
          :column-order="columnOrder"
          :visible-column-ids="visibleColumnIds"
          @close="handleReorderModalClose"
          @confirm="handleReorderConfirm"
          @update:draft-order="handleDraftOrderUpdate"
        />
        <PeriodFilter />
      </div>
    </div>

    <!-- Таблица -->
    <div class="bg-white rounded-lg shadow overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
          <thead class="bg-gray-50 sticky top-0 z-10">
            <tr>
              <!-- Колонка "Товар" - всегда первая и sticky -->
              <th
                v-if="visibleColumnIds.includes('product')"
                class="px-3 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-28 sticky left-0 bg-gray-50 z-20"
              >
                Товар
              </th>
              <!-- Остальные колонки -->
              <th
                v-for="col in visibleDataColumns"
                :key="col.id"
                class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider"
              >
                <div class="flex items-center gap-1">
                  {{ col.label }}
                  <div
                    v-if="col.headerTooltip"
                    class="tooltip-icon"
                    @mouseenter="showTooltip($event, col.headerTooltip)"
                    @mouseleave="hideTooltip"
                  >
                    <svg
                      class="w-4 h-4 text-gray-400 cursor-help"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  </div>
                </div>
              </th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <!-- Итоговая строка -->
            <tr v-if="summary" class="bg-blue-50 font-semibold sticky top-[48px] z-10">
              <!-- Колонка "Товар" -->
              <td
                v-if="visibleColumnIds.includes('product')"
                class="px-3 py-3 text-sm font-bold text-gray-900 sticky left-0 bg-blue-50 z-20"
              >
                Итого
              </td>
              <!-- Остальные колонки -->
              <td
                v-for="col in visibleDataColumns"
                :key="col.id"
                class="px-4 py-3 text-sm"
                :class="renderCell(col, undefined, summary)?.classes || 'text-gray-700'"
              >
                <span v-if="renderCell(col, undefined, summary)?.text">
                  {{ renderCell(col, undefined, summary)?.text }}
                </span>
              </td>
            </tr>

            <!-- Строки артикулов -->
            <template v-for="product in report" :key="product.ni">
              <tr
                class="hover:bg-gray-50 cursor-pointer group"
                @click="toggleProduct(product.ni)"
              >
                <!-- Колонка "Товар" -->
                <td
                  v-if="visibleColumnIds.includes('product')"
                  class="px-3 py-3 sticky left-0 bg-white z-10 group-hover:bg-gray-50"
                >
                  <div class="flex items-center gap-3">
                    <button
                      class="w-5 h-5 flex items-center justify-center text-gray-400 hover:text-gray-600 flex-shrink-0"
                      @click.stop="toggleProduct(product.ni)"
                    >
                      <svg
                        v-if="expandedProducts.has(product.ni)"
                        class="w-4 h-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                      </svg>
                      <svg
                        v-else
                        class="w-4 h-4"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                      </svg>
                    </button>
                    <img
                      v-if="product.img"
                      :src="product.img"
                      :alt="product.title"
                      class="w-12 h-12 object-cover rounded flex-shrink-0"
                      @error="handleImageError"
                    />
                    <div class="flex-1 min-w-0">
                      <div class="text-sm font-medium text-gray-900 truncate">{{ product.ni }}</div>
                      <div
                        class="text-sm text-gray-500 truncate cursor-help"
                        @mouseenter="showTooltip($event, product.title)"
                        @mouseleave="hideTooltip"
                      >
                        {{ product.title }}
                      </div>
                    </div>
                  </div>
                </td>
                <!-- Остальные колонки -->
                <td
                  v-for="col in visibleDataColumns"
                  :key="col.id"
                  class="px-4 py-3 text-sm"
                  :class="renderCell(col, product)?.classes || 'text-gray-700'"
                >
                  <span v-if="renderCell(col, product)?.text">
                    {{ renderCell(col, product)?.text }}
                  </span>
                </td>
              </tr>

              <!-- Строки размеров (вложенные) -->
              <template v-if="expandedProducts.has(product.ni) && product.sizes.length > 0">
                <tr
                  v-for="size in product.sizes"
                  :key="`${product.ni}_${size.sz}`"
                  class="bg-gray-50 hover:bg-gray-100"
                >
                  <!-- Колонка "Товар" для размера -->
                  <td
                    v-if="visibleColumnIds.includes('product')"
                    class="px-3 py-2 pl-12 sticky left-0 bg-gray-50 z-10 group-hover:bg-gray-100"
                  >
                    <div class="text-sm text-gray-600">Размер: {{ size.sz }}</div>
                  </td>
                  <!-- Остальные колонки для размера -->
                  <td
                    v-for="col in visibleDataColumns"
                    :key="col.id"
                    class="px-4 py-2 text-sm"
                    :class="renderCell(col, size)?.classes || 'text-gray-600'"
                  >
                    <span v-if="renderCell(col, size)?.text">
                      {{ renderCell(col, size)?.text }}
                    </span>
                  </td>
                </tr>
              </template>
            </template>

            <!-- Пустое состояние -->
            <tr v-if="report.length === 0">
              <td :colspan="visibleColumns.length" class="px-4 py-8 text-center text-gray-500">
                {{ !store.filters.dateFrom || !store.filters.dateTo ? 'Выберите период' : 'Нет данных' }}
              </td>
            </tr>
          </tbody>
        </table>
    </div>
    </div>
  </div>

  <!-- Tooltip через Teleport -->
  <Teleport to="body">
    <Transition
      enter-active-class="transition-opacity duration-200"
      enter-from-class="opacity-0"
      enter-to-class="opacity-100"
      leave-active-class="transition-opacity duration-150"
      leave-from-class="opacity-100"
      leave-to-class="opacity-0"
    >
      <div
        v-if="tooltipVisible"
        ref="tooltipRef"
        class="fixed tooltip-popup"
        :style="{
          top: tooltipPosition.top + 'px',
          left: tooltipPosition.left + 'px',
          transform: 'translate(-50%, calc(-100% - 8px))',
        }"
      >
        {{ tooltipText }}
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, nextTick } from 'vue'
import { useAnalyticsStore } from '../../stores/analyticsStore'
import PeriodFilter from './PeriodFilter.vue'
import VendorCodeDropdown from './summary/VendorCodeDropdown.vue'
import ColumnsPickerDropdown from './summary/ColumnsPickerDropdown.vue'
import ColumnReorderModal from './summary/ColumnReorderModal.vue'
import PresetsControl from './summary/PresetsControl.vue'
import { useSummaryFilter } from '../composables/useSummaryFilter'
import { useTableColumns } from '../composables/useTableColumns'
import { useTableColumnPresets } from '../composables/useTableColumnPresets'
import { ReportTotalsCalculator } from '../../application/services/ReportTotalsCalculator'
import { summaryColumns, type ColumnDef } from '../summary/summaryColumns'
import type { SizeAggregate, ProductAggregate, ReportTotals } from '../../types/analytics'
import { LocalStorageTableSettingsRepository } from '../../infrastructure/settings/LocalStorageTableSettingsRepository'
import { IndexedDbTablePresetsRepository } from '../../infrastructure/settings/IndexedDbTablePresetsRepository'
import { TablePresetsService } from '../../application/table/TablePresetsService'

const store = useAnalyticsStore()

// Репозиторий для настроек таблицы
const tableSettingsRepo = new LocalStorageTableSettingsRepository()

// Репозиторий и сервис для пресетов
const presetsRepo = new IndexedDbTablePresetsRepository()
const presetsService = new TablePresetsService(presetsRepo)

// Настройки колонок
const tableColumnsApi = useTableColumns(
  summaryColumns,
  tableSettingsRepo,
  'summaryTable:v1'
)

const {
  visibleColumns,
  visibleColumnIds,
  columnOrder,
  toggleColumn,
  resetToDefault,
  applyVisible,
  setVisibleColumnIds,
  setColumnOrder,
} = tableColumnsApi

// Состояние модалки переупорядочивания колонок
const isReorderModalOpen = ref(false)

// Исходный порядок колонок для отката при Cancel
const initialColumnOrder = ref<string[]>([])

// Обработчик изменения draft-order (применяется временно к таблице)
const handleDraftOrderUpdate = async (newOrder: string[]) => {
  // Применяем изменения временно (без сохранения)
  await setColumnOrder(newOrder, true)
}

// Обработчик подтверждения переупорядочивания колонок
const handleReorderConfirm = async (newOrder: string[]) => {
  // Очищаем initialColumnOrder сразу в начале, чтобы предотвратить rollback при закрытии
  initialColumnOrder.value = []
  
  // Сохраняем изменения в localStorage
  // Важно: newOrder должен содержать ВСЕ колонки в правильном порядке
  await setColumnOrder(newOrder, false)
  
  // Ждем следующего тика, чтобы убедиться, что columnOrder обновлен реактивно
  await nextTick()
  
  // Если активен пресет, сохраняем изменения в него
  if (activePresetId.value && activePreset.value && !activePreset.value.isBuiltIn) {
    try {
      // Используем обновленный columnOrder.value после setColumnOrder
      // чтобы гарантировать сохранение правильного порядка (с учетом валидации)
      const orderToSave = [...columnOrder.value] // Создаем копию, чтобы избежать проблем с реактивностью
      await presetsService.saveActive('summaryTable', activePresetId.value, {
        visibleColumnIds: [...visibleColumnIds.value],
        columnOrder: orderToSave,
      })
      // Обновляем список пресетов БЕЗ переприменения пресета
      // Важно: обновляем список после сохранения, но не применяем пресет снова
      presets.value = await presetsService.list('summaryTable')
    } catch (error) {
      console.error('[SummaryView] Error saving preset after reorder:', error)
      alert('Ошибка сохранения пресета: ' + (error instanceof Error ? error.message : String(error)))
    }
  }
  
  // Закрываем модалку после успешного сохранения
  isReorderModalOpen.value = false
}

// Обработчик закрытия модалки (откат изменений при Cancel)
const handleReorderModalClose = async () => {
  // Откатываем изменения к исходному состоянию
  if (initialColumnOrder.value.length > 0) {
    await setColumnOrder(initialColumnOrder.value, true)
    initialColumnOrder.value = []
  }
  isReorderModalOpen.value = false
}

// Обработчик открытия модалки
const handleReorderModalOpen = () => {
  // Сохраняем текущий порядок для отката
  initialColumnOrder.value = [...columnOrder.value]
  isReorderModalOpen.value = true
}

// Пресеты колонок
const {
  presets,
  activePresetId,
  activePreset,
  isDirty,
  isLoading: presetsLoading,
  init: initPresets,
  applyPreset,
  saveActive,
  saveAs,
  renamePreset,
  deletePreset,
} = useTableColumnPresets('summaryTable', {
  visibleColumnIds,
  columnOrder,
  setVisibleColumnIds,
  setColumnOrder,
}, presetsService)

// Обработчики событий пресетов
const handlePresetSelect = async (presetId: string) => {
  try {
    await applyPreset(presetId)
  } catch (error) {
    console.error('[SummaryView] Error applying preset:', error)
    alert('Ошибка применения пресета: ' + (error instanceof Error ? error.message : String(error)))
  }
}

const handlePresetSave = async () => {
  try {
    await saveActive()
  } catch (error) {
    console.error('[SummaryView] Error saving preset:', error)
    alert('Ошибка сохранения пресета: ' + (error instanceof Error ? error.message : String(error)))
  }
}

const handlePresetSaveAs = async (name: string) => {
  try {
    await saveAs(name)
  } catch (error) {
    console.error('[SummaryView] Error saving preset as:', error)
    alert('Ошибка сохранения пресета: ' + (error instanceof Error ? error.message : String(error)))
  }
}

const handlePresetRename = async (name: string) => {
  if (!activePresetId.value) return
  try {
    await renamePreset(activePresetId.value, name)
  } catch (error) {
    console.error('[SummaryView] Error renaming preset:', error)
    alert('Ошибка переименования пресета: ' + (error instanceof Error ? error.message : String(error)))
  }
}

const handlePresetDelete = async () => {
  if (!activePresetId.value) return
  try {
    await deletePreset(activePresetId.value)
  } catch (error) {
    console.error('[SummaryView] Error deleting preset:', error)
    alert('Ошибка удаления пресета: ' + (error instanceof Error ? error.message : String(error)))
  }
}

// Состояние раскрытых артикулов
const expandedProducts = ref<Set<number>>(new Set())

// Видимые колонки без "product" (product всегда первая и sticky)
const visibleDataColumns = computed(() => {
  return visibleColumns.value.filter(col => col.id !== 'product')
})

// Получаем данные из store
const sourceData = computed(() => store.aggregatedReport)

// Фильтрация данных
const {
  searchQuery,
  selectedVendorCodes,
  filteredRows,
} = useSummaryFilter(sourceData)

// Уникальные vendorCode (sa) из aggregatedReport для dropdown
const vendorOptions = computed(() => {
  const vendorMap = new Map<string, { code: string; title?: string }>()

  store.aggregatedReport.forEach((product: ProductAggregate) => {
    if (product.sa && !vendorMap.has(product.sa)) {
      vendorMap.set(product.sa, {
        code: product.sa,
        title: product.title,
      })
    }
  })

  return Array.from(vendorMap.values()).sort((a, b) => a.code.localeCompare(b.code))
})

// Используем отфильтрованные данные
const report = filteredRows

// Вычисляем итоги по отфильтрованным данным
const summary = computed(() => {
  return ReportTotalsCalculator.calculateTotals(
    filteredRows.value,
    store.storageCosts,
    store.acceptanceCosts,
    store.filters.dateFrom || undefined,
    store.filters.dateTo || undefined
  )
})

// Переключение раскрытия артикула
const toggleProduct = (ni: number) => {
  if (expandedProducts.value.has(ni)) {
    expandedProducts.value.delete(ni)
  } else {
    expandedProducts.value.add(ni)
  }
}

// Форматирование валюты
const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value)
}

const formatBuyoutPercent = (value: number): string => {
  return value.toFixed(1) + '%'
}

const getBuyoutPercentClass = (value: number): string => {
  if (value < 30) return 'text-red-600 font-semibold'
  if (value > 70) return 'text-green-600 font-semibold'
  return 'text-gray-700'
}

const formatPercent = (value: number): string => {
  return value.toFixed(2) + '%'
}

const getMarginPercentClass = (value: number): string => {
  if (value < 0) return 'text-red-600 font-semibold'
  if (value > 20) return 'text-green-600 font-semibold'
  if (value > 10) return 'text-green-500'
  return 'text-gray-700'
}

const getRoiPercentClass = (value: number): string => {
  if (value < 0) return 'text-red-600 font-semibold'
  if (value > 100) return 'text-green-600 font-semibold'
  if (value > 50) return 'text-green-500'
  if (value > 0) return 'text-gray-700'
  return 'text-gray-500'
}

// Обработка ошибки загрузки изображения
const handleImageError = (event: Event) => {
  const img = event.target as HTMLImageElement
  img.style.display = 'none'
}

// Helper функция для рендеринга ячейки колонки
const renderCell = (col: ColumnDef<ProductAggregate, ReportTotals>, row?: ProductAggregate | SizeAggregate, totals?: ReportTotals) => {
  if (col.id === 'product') {
    return null // Обрабатывается отдельно
  }

  let result: string | { text: string; classes?: string } | '—' | null = null
  
  if (totals && col.totalCell) {
    result = col.totalCell(totals)
  } else if (row) {
    const isSize = 'sz' in row
    if (isSize && col.sizeCell) {
      // Это размер, используем sizeCell
      result = col.sizeCell(row as SizeAggregate)
    } else if (isSize && col.cell) {
      // Это размер, но нет sizeCell, используем cell с приведением через unknown
      result = col.cell(row as unknown as ProductAggregate)
    } else if (!isSize && col.cell) {
      // Это продукт
      result = col.cell(row as ProductAggregate)
    }
  }

  if (result === null || result === undefined) {
    return { text: '', classes: '' }
  }

  if (result === '—') {
    return { text: '—', classes: '' }
  }

  if (typeof result === 'string') {
    return { text: result, classes: '' }
  }

  return result
}

// Tooltip состояние
const tooltipRef = ref<HTMLDivElement | null>(null)
const tooltipVisible = ref(false)
const tooltipText = ref('')
const tooltipPosition = ref({ top: 0, left: 0 })
let tooltipTimeout: number | null = null

// Показать tooltip
const showTooltip = (event: MouseEvent, text: string) => {
  if (tooltipTimeout) {
    clearTimeout(tooltipTimeout)
  }
  
  tooltipText.value = text
  const target = event.currentTarget as HTMLElement
  const rect = target.getBoundingClientRect()
  
  // Вычисляем позицию: над иконкой с небольшим смещением (8px)
  tooltipPosition.value = {
    top: rect.top - 8, // 8px offset
    left: rect.left + rect.width / 2
  }
  
  tooltipTimeout = window.setTimeout(() => {
    tooltipVisible.value = true
  }, 300)
}

// Скрыть tooltip
const hideTooltip = () => {
  if (tooltipTimeout) {
    clearTimeout(tooltipTimeout)
    tooltipTimeout = null
  }
  tooltipVisible.value = false
}

// Обновить позицию при скролле
const updateTooltipPosition = () => {
  if (tooltipVisible.value && tooltipRef.value) {
    // Позиция будет обновлена при следующем hover
  }
}

onMounted(async () => {
  window.addEventListener('scroll', updateTooltipPosition, true)
  window.addEventListener('resize', updateTooltipPosition)
  
  // Инициализируем пресеты после загрузки настроек колонок
  // Пресеты имеют приоритет и перезаписывают настройки из localStorage
  await initPresets()
})

onBeforeUnmount(() => {
  window.removeEventListener('scroll', updateTooltipPosition, true)
  window.removeEventListener('resize', updateTooltipPosition)
  if (tooltipTimeout) {
    clearTimeout(tooltipTimeout)
  }
})
</script>

<style scoped>
.tooltip-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
</style>

<style>
.tooltip-popup {
  z-index: 9999;
  background-color: rgba(31, 41, 55, 0.95);
  color: white;
  text-align: center;
  border-radius: 6px;
  padding: 8px 12px;
  white-space: nowrap;
  font-size: 12px;
  font-weight: normal;
  pointer-events: none;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
}

.tooltip-popup::after {
  content: '';
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: rgba(31, 41, 55, 0.95) transparent transparent transparent;
}
</style>
