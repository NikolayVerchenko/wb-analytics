<template>
  <div class="min-h-screen bg-gray-100">
    <!-- Верхнее меню -->
    <TopMenu />

    <!-- Основной контент -->
    <main class="max-w-7xl mx-auto px-4 py-8">
      <router-view v-slot="{ Component }">
        <component :is="Component" />
      </router-view>
    </main>

    <!-- Toast-уведомления -->
    <ToastContainer />
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { provideDI } from './presentation/composables/useDependencyInjection'
import TopMenu from './presentation/components/TopMenu.vue'
import ToastContainer from './presentation/components/ToastContainer.vue'
import { toastService } from './presentation/services/ToastService'
import { useAnalyticsStore } from '@/stores/analyticsStore'
import { container } from '@/core/di/container'
import { TOKENS } from '@/core/di/tokens'

// Предоставляем DI для дочерних компонентов
provideDI()

// Инициализируем analyticsStore и загружаем данные
const analyticsStore = useAnalyticsStore()

onMounted(async () => {
  // Проверяем наличие API ключа
  const apiKey = localStorage.getItem('wb_api_key')
  if (apiKey) {
    analyticsStore.initializeServices(
      container.resolve(TOKENS.dataLoadingService),
      container.resolve(TOKENS.reportAggregationService),
      container.resolve(TOKENS.supplyService)
    )
  }

  // Загружаем данные из БД в store
  try {
    await analyticsStore.loadAllDataFromDb()
  } catch (error) {
    console.error('Ошибка при загрузке данных в store:', error)
  }
})

</script>
