export { DataAggregator } from './DataAggregator'
export type { AggregatedSale, AggregatedReturn } from './DataAggregator'
