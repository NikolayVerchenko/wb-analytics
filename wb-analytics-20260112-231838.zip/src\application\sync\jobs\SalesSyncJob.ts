import type { SyncJob, SyncContext, SyncPlan } from '../SyncJob'
import type { Checkpoint } from '../types'
import type { DatasetPolicy } from '../SyncPolicy'
import { planForMode } from '../BasePlanner'
import { defaultHighWatermark } from '../date'
import { buildWeeklyRefreshPlan } from '../planning'
import type { WbApiClient } from '../../../api/WbApiClient'
import { db } from '../../../db/db'
import type { ISale, WBReportRow } from '../../../types/db'
import { mapToSale } from './helpers'

/**
 * SyncJob для синхронизации продаж (sales)
 * Поддерживает два режима:
 * - daily: ежедневная загрузка с пагинацией (dataset='sales')
 * - weekly: еженедельная загрузка закрытой недели (dataset='sales_weekly')
 */
export class SalesSyncJob implements SyncJob {
  dataset: 'sales' | 'sales_weekly'

  constructor(
    private readonly apiClient: WbApiClient,
    private readonly policy: DatasetPolicy,
    dataset?: 'sales' | 'sales_weekly'
  ) {
    // По умолчанию 'sales' для обратной совместимости
    this.dataset = dataset || 'sales'
  }

  async plan(ctx: SyncContext, checkpoint: Checkpoint | null): Promise<SyncPlan | null> {
    // Для daily sales используем базовый планировщик
    if (this.dataset === 'sales') {
      return planForMode(ctx, this.dataset, checkpoint, this.policy, 'catchup')
    }

    // Для weekly sales используем buildWeeklyRefreshPlan
    // (вызывается в runRefreshWave через runner.run)
    return buildWeeklyRefreshPlan('sales_weekly', ctx.nowIso(), checkpoint)
  }

  async fetch(ctx: SyncContext, plan: SyncPlan): Promise<unknown[]> {
    const granularity = plan.granularity || 'daily'
    console.log(`[SalesSyncJob] fetch: начало загрузки ${plan.dataset} (${granularity}) за период ${plan.range.from} - ${plan.range.to}`)

    // Конвертируем даты в RFC3339 формат для API
    const dateFrom = `${plan.range.from}T00:00:00.000Z`
    const dateTo = `${plan.range.to}T23:59:59.999Z`

    const allItems: ISale[] = []

    if (granularity === 'weekly') {
      // Weekly режим: загрузка недели одним запросом
      // TODO: replace with real weekly report endpoint if available
      // Пока используем fetchReportPage с period='weekly'
      let lastRrdId: number | undefined = undefined

      while (true) {
        const pageItems = await this.apiClient.fetchReportPage(dateFrom, dateTo, 'weekly', lastRrdId)

        if (pageItems.length === 0) {
          break
        }

        const salesItems = (pageItems as WBReportRow[])
          .filter(item => item.supplier_oper_name === 'Продажа')
          .map(item => mapToSale(item))

        allItems.push(...salesItems)

        const lastItem = pageItems[pageItems.length - 1] as WBReportRow
        lastRrdId = lastItem.rrd_id

        if (pageItems.length < 100000) {
          break
        }
      }
    } else {
      // Daily режим: загрузка с пагинацией (как было)
      let lastRrdId: number | undefined = undefined

      while (true) {
        const pageItems = await this.apiClient.fetchReportPage(dateFrom, dateTo, 'weekly', lastRrdId)

        if (pageItems.length === 0) {
          break
        }

        const salesItems = (pageItems as WBReportRow[])
          .filter(item => item.supplier_oper_name === 'Продажа')
          .map(item => mapToSale(item))

        allItems.push(...salesItems)

        const lastItem = pageItems[pageItems.length - 1] as WBReportRow
        lastRrdId = lastItem.rrd_id

        if (pageItems.length < 100000) {
          break
        }
      }
    }

    console.log(`[SalesSyncJob] fetch: загружено ${allItems.length} записей продаж (${granularity})`)
    return allItems
  }

  async apply(ctx: SyncContext, plan: SyncPlan, items: unknown[]): Promise<{ applied: number }> {
    const sales = items as ISale[]

    if (sales.length === 0) {
      return { applied: 0 }
    }

    const granularity = plan.granularity || 'daily'
    console.log(`[SalesSyncJob] apply: начало сохранения ${sales.length} записей продаж в БД (${granularity})`)

    // Используем bulkPut для идемпотентного UPSERT
    await db.sales.bulkPut(sales)

    console.log(`[SalesSyncJob] apply: сохранено ${sales.length} записей продаж`)
    return { applied: sales.length }
  }

  buildNextCheckpoint(ctx: SyncContext, plan: SyncPlan, _prev: Checkpoint | null, _fetched: number): Checkpoint {
    const granularity = plan.granularity || 'daily'
    
    if (granularity === 'weekly') {
      // Для weekly checkpoint сохраняем до конца недели (range.to)
      return {
        dataset: this.dataset, // sales_weekly
        cursorTime: plan.range.to,
        highWatermarkTime: plan.range.to,
        updatedAt: ctx.nowIso(),
      }
    }

    // Для daily checkpoint - как было
    const high = defaultHighWatermark(ctx.nowIso())
    
    return {
      dataset: this.dataset, // sales
      cursorTime: plan.range.to,
      highWatermarkTime: high,
      updatedAt: ctx.nowIso(),
    }
  }
}
