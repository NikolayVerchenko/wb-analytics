import type { DatasetKey, Checkpoint, SyncRunResult } from './types'
import type { SyncJob, SyncContext } from './SyncJob'

export type RunnerOptions = {
  /**
   * Принудительный refresh последних N дней (overlap),
   * полезно для "плавающих" данных.
   */
  refreshOverlapDays?: number
}

export class SyncRunner {
  constructor(
    private readonly ctx: SyncContext,
    private readonly jobs: Record<DatasetKey, SyncJob>
  ) {}

  async run(dataset: DatasetKey, opts?: RunnerOptions): Promise<SyncRunResult | null> {
    const job = this.jobs[dataset]
    if (!job) {
      throw new Error(`SyncJob not registered for dataset=${dataset}`)
    }

    const prev = await this.ctx.checkpointRepo.get(dataset)
    const plan = await job.plan(this.ctx, prev)

    if (!plan) return null

    // опционально усиливаем refresh overlap, если передали
    if (opts?.refreshOverlapDays !== undefined) {
      plan.mode = 'refresh'
      plan.overlapDays = opts.refreshOverlapDays
    }

    const items = await job.fetch(this.ctx, plan)

    // apply должен быть идемпотентным (UPSERT)
    const { applied } = await job.apply(this.ctx, plan, items)

    // checkpoint обновляем ТОЛЬКО после успешного apply
    const nextCheckpoint = job.buildNextCheckpoint(this.ctx, plan, prev, items.length)
    await this.ctx.checkpointRepo.upsert(nextCheckpoint)

    return {
      dataset,
      fetched: items.length,
      applied,
      nextCheckpoint,
    }
  }
}
