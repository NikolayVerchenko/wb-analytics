import type { SyncContext } from '../sync/SyncJob'
import type { SyncPolicy } from '../sync/SyncPolicy'
import type { OrchestratorOptions } from '../sync/SyncOrchestrator'
import { SyncRegistry } from '../sync/SyncRegistry'
import { SyncOrchestrator } from '../sync/SyncOrchestrator'
import type { WbApiClient } from '../../api/WbApiClient'
import { defaultSyncPolicy } from '../sync/SyncPolicy'
import type { DatasetKey, Checkpoint } from '../sync/types'

/**
 * Сервис-обёртка над SyncOrchestrator для удобного использования
 */
export class SmartSyncService {
  private orchestrator: SyncOrchestrator | null = null

  constructor(
    private readonly ctx: SyncContext,
    private readonly apiClient: WbApiClient,
    private readonly policy: SyncPolicy = defaultSyncPolicy,
    private readonly opts: OrchestratorOptions = {
      priorityDatasets: ['sales', 'returns', 'advCosts'],
      historyDatasets: ['sales', 'returns', 'logistics', 'penalties', 'advCosts'],
      maxCatchupRunsPerTick: 5,
    }
  ) {}

  private getOrchestrator(): SyncOrchestrator {
    if (!this.orchestrator) {
      this.orchestrator = SyncRegistry.createOrchestrator(this.ctx, this.apiClient, this.policy, this.opts)
    }
    return this.orchestrator
  }

  /**
   * Быстрый старт: priority wave
   * Загружает последние N дней по всем приоритетным datasets для UI
   */
  async runInitialPriority(): Promise<void> {
    console.log('[SmartSyncService] runInitialPriority: начало приоритетной загрузки')
    const orchestrator = this.getOrchestrator()
    await orchestrator.runPriorityWave()
    console.log('[SmartSyncService] runInitialPriority: завершено')
  }

  /**
   * Фоновый догон истории: один тик
   * Делает максимум maxCatchupRunsPerTick запусков catchup
   */
  async runBackgroundCatchupOnce(): Promise<{ runs: number }> {
    console.log('[SmartSyncService] runBackgroundCatchupOnce: начало фонового догона')
    const orchestrator = this.getOrchestrator()
    const result = await orchestrator.runCatchupTick()
    console.log(`[SmartSyncService] runBackgroundCatchupOnce: завершено, выполнено ${result.runs} запусков`)
    return result
  }

  /**
   * Refresh wave: обновление плавающих данных
   * Перезагружает последние overlapDays для приоритетных datasets
   */
  async runRefreshWave(): Promise<void> {
    console.log('[SmartSyncService] runRefreshWave: начало refresh')
    const orchestrator = this.getOrchestrator()
    await orchestrator.runRefreshWave()
    console.log('[SmartSyncService] runRefreshWave: завершено')
  }

  /**
   * Получить статус синхронизации по всем datasets
   */
  async getSyncStatus(): Promise<Record<DatasetKey, { checkpoint: Checkpoint | null }>> {
    const status: Partial<Record<DatasetKey, { checkpoint: Checkpoint | null }>> = {}
    const datasets: DatasetKey[] = [
      'sales',
      'returns',
      'logistics',
      'penalties',
      'advCosts',
      'storageCosts',
      'acceptanceCosts',
      'productOrders',
      'supplies',
    ]

    for (const dataset of datasets) {
      const checkpoint = await this.ctx.checkpointRepo.get(dataset)
      status[dataset] = { checkpoint }
    }

    return status as Record<DatasetKey, { checkpoint: Checkpoint | null }>
  }
}
