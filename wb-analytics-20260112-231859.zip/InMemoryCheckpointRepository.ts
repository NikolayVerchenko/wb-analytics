import type { CheckpointRepository } from './CheckpointRepository'
import type { DatasetKey, Checkpoint } from './types'

export class InMemoryCheckpointRepository implements CheckpointRepository {
  private store = new Map<DatasetKey, Checkpoint>()

  async get(dataset: DatasetKey): Promise<Checkpoint | null> {
    return this.store.get(dataset) ?? null
  }

  async upsert(checkpoint: Checkpoint): Promise<void> {
    this.store.set(checkpoint.dataset, checkpoint)
  }
}
