<template>
  <div class="space-y-4">
    <slot />
  </div>
</template>

<script setup lang="ts">
</script>

