import type { DatasetKey } from './types'
import type { SyncRunner } from './SyncRunner'
import type { SyncPolicy } from './SyncPolicy'
import type { SyncContext } from './SyncJob'
import { isWeeklyRebuildWindow } from './date'

export type OrchestratorOptions = {
  /**
   * Какие датасеты синкаем в приоритете при старте (обычно все финансовые)
   */
  priorityDatasets: DatasetKey[]

  /**
   * Какие датасеты догоняем в фоне (обычно те же + тяжелые)
   */
  historyDatasets: DatasetKey[]

  /**
   * За один проход catchup делаем максимум N запусков (чтобы не повесить устройство)
   */
  maxCatchupRunsPerTick: number
}

export class SyncOrchestrator {
  constructor(
    private readonly ctx: SyncContext,
    private readonly runner: SyncRunner,
    private readonly policy: SyncPolicy,
    private readonly opts: OrchestratorOptions
  ) {}

  /**
   * Быстрый старт: priority wave
   * Идея: UI сразу получает актуальные последние N дней
   */
  async runPriorityWave(): Promise<void> {
    for (const dataset of this.opts.priorityDatasets) {
      // runner.run сам вытащит checkpoint; но plan mode у job пока внутри job.
      // Поэтому на шаге 3 мы запускаем как "обычный run" + опциональный refreshOverlapDays.
      await this.runner.run(dataset, { refreshOverlapDays: this.policy[dataset].refreshOverlapDays })
    }
  }

  /**
   * Фоновый догон истории:
   * - несколько "тиков"
   * - в каждом тике ограничиваем число запусков
   */
  async runCatchupTick(): Promise<{ runs: number }> {
    let runs = 0

    for (const dataset of this.opts.historyDatasets) {
      if (runs >= this.opts.maxCatchupRunsPerTick) break

      // один запуск = один chunk
      const res = await this.runner.run(dataset)
      if (res) runs++
    }

    return { runs }
  }

  /**
   * Refresh tick — пересинк последних overlapDays (плавающие данные)
   * Порядок выполнения:
   * 1. Сначала daily refresh для всех приоритетных datasets
   * 2. Затем (если окно Пн/Вт) weekly refresh для sales предыдущей недели
   * 
   * Weekly refresh выполняется только в Пн/Вт для предыдущей закрытой недели
   * job.plan() для sales_weekly сам проверит окно и checkpoint через buildWeeklyRefreshPlan
   */
  async runRefreshWave(): Promise<void> {
    const nowIso = this.ctx.nowIso()

    // 1. Daily refresh для всех приоритетных datasets
    for (const dataset of this.opts.priorityDatasets) {
      await this.runner.run(dataset, { refreshOverlapDays: this.policy[dataset].refreshOverlapDays })
    }

    // 2. Weekly refresh для sales (если окно Пн/Вт)
    // job.plan() для sales_weekly сам проверит необходимость через buildWeeklyRefreshPlan
    if (isWeeklyRebuildWindow(nowIso)) {
      console.log(`[SyncOrchestrator] runRefreshWave: проверка weekly refresh для sales`)
      await this.runner.run('sales_weekly', { refreshOverlapDays: this.policy.sales_weekly.refreshOverlapDays })
    }
  }
}
