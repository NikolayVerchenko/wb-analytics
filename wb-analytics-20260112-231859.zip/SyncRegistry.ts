import type { DatasetKey } from './types'
import type { SyncJob } from './SyncJob'
import type { SyncContext } from './SyncJob'
import type { SyncPolicy, DatasetPolicy } from './SyncPolicy'
import { SyncRunner } from './SyncRunner'
import { SyncOrchestrator, type OrchestratorOptions } from './SyncOrchestrator'
import type { WbApiClient } from '../../api/WbApiClient'
import { SalesSyncJob } from './jobs/SalesSyncJob'
import { ReturnsSyncJob } from './jobs/ReturnsSyncJob'
import { LogisticsSyncJob } from './jobs/LogisticsSyncJob'
import { PenaltiesSyncJob } from './jobs/PenaltiesSyncJob'

/**
 * Реестр всех SyncJob и фабрика для создания SyncRunner и SyncOrchestrator
 */
export class SyncRegistry {
  /**
   * Создает все зарегистрированные jobs
   */
  static buildJobs(
    ctx: SyncContext,
    apiClient: WbApiClient,
    policy: SyncPolicy
  ): Record<DatasetKey, SyncJob> {
    const jobs: Partial<Record<DatasetKey, SyncJob>> = {}

    // Финансовые таблицы из fetchReportPage
    jobs.sales = new SalesSyncJob(apiClient, policy.sales, 'sales')
    jobs.sales_weekly = new SalesSyncJob(apiClient, policy.sales_weekly, 'sales_weekly')
    jobs.returns = new ReturnsSyncJob(apiClient, policy.returns)
    jobs.logistics = new LogisticsSyncJob(apiClient, policy.logistics)
    jobs.penalties = new PenaltiesSyncJob(apiClient, policy.penalties)

    // TODO: добавить остальные jobs по мере реализации:
    // jobs.advCosts = new AdvCostsSyncJob(apiClient, policy.advCosts)
    // jobs.storageCosts = new StorageCostsSyncJob(apiClient, policy.storageCosts)
    // jobs.acceptanceCosts = new AcceptanceCostsSyncJob(apiClient, policy.acceptanceCosts)
    // jobs.productOrders = new ProductOrdersSyncJob(apiClient, policy.productOrders)
    // jobs.supplies = new SuppliesSyncJob(apiClient, policy.supplies)

    return jobs as Record<DatasetKey, SyncJob>
  }

  /**
   * Создает SyncRunner с зарегистрированными jobs
   */
  static createRunner(
    ctx: SyncContext,
    apiClient: WbApiClient,
    policy: SyncPolicy
  ): SyncRunner {
    const jobs = this.buildJobs(ctx, apiClient, policy)
    return new SyncRunner(ctx, jobs)
  }

  /**
   * Создает SyncOrchestrator
   */
  static createOrchestrator(
    ctx: SyncContext,
    apiClient: WbApiClient,
    policy: SyncPolicy,
    opts: OrchestratorOptions
  ): SyncOrchestrator {
    const runner = this.createRunner(ctx, apiClient, policy)
    return new SyncOrchestrator(ctx, runner, policy, opts)
  }
}
