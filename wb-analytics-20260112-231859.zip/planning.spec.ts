import { describe, it, expect } from 'vitest'
import { buildWeeklyRefreshPlan } from '../planning'
import type { Checkpoint } from '../types'

describe('buildWeeklyRefreshPlan', () => {
  it('should return null outside Monday/Tuesday window', () => {
    const wednesday = '2024-01-10' // Среда
    const plan = buildWeeklyRefreshPlan('sales_weekly', wednesday, null)
    expect(plan).toBeNull()
  })

  it('should return plan on Monday when checkpoint is missing', () => {
    const monday = '2024-01-08' // Понедельник
    const plan = buildWeeklyRefreshPlan('sales_weekly', monday, null)

    expect(plan).not.toBeNull()
    expect(plan?.dataset).toBe('sales_weekly')
    expect(plan?.mode).toBe('refresh')
    expect(plan?.granularity).toBe('weekly')
    // Предыдущая неделя: 1-7 января (пн-вс)
    expect(plan?.range.from).toBe('2024-01-01')
    expect(plan?.range.to).toBe('2024-01-07')
  })

  it('should return plan on Tuesday when checkpoint is missing', () => {
    const tuesday = '2024-01-09' // Вторник
    const plan = buildWeeklyRefreshPlan('sales_weekly', tuesday, null)

    expect(plan).not.toBeNull()
    expect(plan?.dataset).toBe('sales_weekly')
    expect(plan?.mode).toBe('refresh')
    expect(plan?.granularity).toBe('weekly')
  })

  it('should return null when checkpoint is already up to date', () => {
    const monday = '2024-01-08' // Понедельник
    const checkpoint: Checkpoint = {
      dataset: 'sales_weekly',
      cursorTime: '2024-01-07', // Уже обработана предыдущая неделя (до 7 января)
      updatedAt: '2024-01-08',
    }

    const plan = buildWeeklyRefreshPlan('sales_weekly', monday, checkpoint)
    expect(plan).toBeNull()
  })

  it('should return plan when checkpoint is outdated', () => {
    const monday = '2024-01-08' // Понедельник
    const checkpoint: Checkpoint = {
      dataset: 'sales_weekly',
      cursorTime: '2023-12-31', // Старая дата
      updatedAt: '2023-12-31',
    }

    const plan = buildWeeklyRefreshPlan('sales_weekly', monday, checkpoint)
    expect(plan).not.toBeNull()
    expect(plan?.range.from).toBe('2024-01-01')
    expect(plan?.range.to).toBe('2024-01-07')
  })

  it('should return null when checkpoint cursorTime equals range.to', () => {
    const monday = '2024-01-08' // Понедельник
    const checkpoint: Checkpoint = {
      dataset: 'sales_weekly',
      cursorTime: '2024-01-07', // Точно до конца предыдущей недели
      updatedAt: '2024-01-08',
    }

    const plan = buildWeeklyRefreshPlan('sales_weekly', monday, checkpoint)
    expect(plan).toBeNull()
  })
})
