import type { CheckpointRepository } from './CheckpointRepository'
import type { DatasetKey, Checkpoint } from './types'
import { db } from '../../db/db'

/**
 * Реализация CheckpointRepository на основе Dexie (IndexedDB)
 * Хранит чекпоинты в таблице settings с ключом `sync_checkpoint_${dataset}`
 */
export class DbCheckpointRepository implements CheckpointRepository {
  private readonly KEY_PREFIX = 'sync_checkpoint_'

  private getKey(dataset: DatasetKey): string {
    return `${this.KEY_PREFIX}${dataset}`
  }

  async get(dataset: DatasetKey): Promise<Checkpoint | null> {
    const key = this.getKey(dataset)
    const record = await db.settings.get(key)
    
    if (!record) {
      return null
    }

    try {
      return JSON.parse(record.value) as Checkpoint
    } catch (error) {
      console.error(`[DbCheckpointRepository] Ошибка парсинга checkpoint для ${dataset}:`, error)
      return null
    }
  }

  async upsert(checkpoint: Checkpoint): Promise<void> {
    const key = this.getKey(checkpoint.dataset)
    const value = JSON.stringify(checkpoint)
    
    await db.settings.put({
      key,
      value,
    })
  }
}
