export type DatasetKey =
  | 'sales'
  | 'sales_weekly'
  | 'returns'
  | 'logistics'
  | 'penalties'
  | 'advCosts'
  | 'storageCosts'
  | 'acceptanceCosts'
  | 'productOrders'
  | 'supplies'

export type SyncStatus = 'idle' | 'running' | 'paused' | 'error'

export type Checkpoint = {
  dataset: DatasetKey

  /**
   * До какого момента по времени данные гарантированно загружены
   * ISO строка, без timezone-магии
   */
  cursorTime?: string

  /**
   * Для постраничных API (pageToken / cursor / offset)
   */
  cursorToken?: string

  /**
   * Верхняя стабильная граница (например: "вчера 23:59")
   * За неё синк пока не заходит
   */
  highWatermarkTime?: string

  /**
   * Когда checkpoint был обновлён
   */
  updatedAt: string
}

export type SyncRunResult = {
  dataset: DatasetKey
  fetched: number
  applied: number
  nextCheckpoint: Checkpoint
}
