import type { DatasetKey, Checkpoint } from './types'
import type { SyncPlan } from './SyncJob'
import type { DatasetPolicy } from './SyncPolicy'
import { addDays, defaultHighWatermark, lastClosedWeekRange, isWeeklyRebuildWindow } from './date'

type PlanInput = {
  dataset: DatasetKey
  policy: DatasetPolicy
  nowIso: string
  checkpoint: Checkpoint | null
}

/**
 * Вычисляет нижнюю границу истории (не глубже maxHistoryDays).
 */
const clampHistoryStart = (high: string, maxHistoryDays: number | null): string | null => {
  if (!maxHistoryDays) return null
  return addDays(high, -maxHistoryDays)
}

/**
 * PRIORITY: последние policy.priorityDays (быстро для UI)
 * Возвращает plan с mode='refresh' (по сути "перезалив" последних дней)
 */
export const buildPriorityPlan = (inp: PlanInput): SyncPlan => {
  const high = defaultHighWatermark(inp.nowIso)
  const from = addDays(high, -inp.policy.priorityDays + 1)
  return {
    dataset: inp.dataset,
    mode: 'refresh',
    overlapDays: inp.policy.refreshOverlapDays,
    range: { from, to: high },
    granularity: 'daily',
  }
}

/**
 * REFRESH: небольшой overlap около highWatermark (плавающие данные)
 * Например, последние 3-7 дней.
 */
export const buildRefreshPlan = (inp: PlanInput): SyncPlan => {
  const high = defaultHighWatermark(inp.nowIso)
  const from = addDays(high, -inp.policy.refreshOverlapDays + 1)
  return {
    dataset: inp.dataset,
    mode: 'refresh',
    overlapDays: inp.policy.refreshOverlapDays,
    range: { from, to: high },
    granularity: 'daily',
  }
}

/**
 * WEEKLY REFRESH: обновление закрытой недели (пн-вс) в окне Пн/Вт
 * Выполняется только в понедельник или вторник для предыдущей закрытой недели
 * 
 * Логика:
 * - если сегодня не Пн/Вт => null
 * - диапазон: lastClosedWeekRange(todayIso) (пн-вс предыдущей недели)
 * - если weekly checkpoint уже >= range.to => null (уже делали)
 * - иначе вернуть план с granularity='weekly'
 */
export const buildWeeklyRefreshPlan = (
  dataset: DatasetKey,
  nowIso: string,
  checkpointWeekly: Checkpoint | null
): SyncPlan | null => {
  // Проверяем окно weekly rebuild (Пн/Вт)
  if (!isWeeklyRebuildWindow(nowIso)) {
    return null
  }

  // Получаем диапазон последней закрытой недели
  const weekRange = lastClosedWeekRange(nowIso)

  // Если weekly checkpoint уже обновлён до конца этой недели - пропускаем
  if (checkpointWeekly?.cursorTime && checkpointWeekly.cursorTime >= weekRange.to) {
    return null
  }

  return {
    dataset,
    mode: 'refresh',
    range: weekRange,
    granularity: 'weekly',
  }
}

/**
 * CATCHUP: догоняем историю чанками, используя checkpoint.cursorTime
 * cursorTime = "до какой даты мы уже дособрали"
 *
 * Логика:
 * - start = checkpoint?.cursorTime ?? (high - maxHistoryDays)
 * - берем chunkDays вперед: [start .. min(start+chunkDays-1, high)]
 * - если start > high => null (догнали)
 */
export const buildCatchupPlan = (inp: PlanInput): SyncPlan | null => {
  const high = defaultHighWatermark(inp.nowIso)
  const minStart = clampHistoryStart(high, inp.policy.maxHistoryDays)

  const start = inp.checkpoint?.cursorTime ?? (minStart ?? addDays(high, -365))
  if (start > high) return null

  // если есть ограничение по истории — не идем раньше minStart
  const from = minStart ? (start < minStart ? minStart : start) : start
  if (from > high) return null

  const to = addDays(from, inp.policy.catchupChunkDays - 1)
  const clampedTo = to > high ? high : to

  return {
    dataset: inp.dataset,
    mode: 'catchup',
    range: { from, to: clampedTo },
    granularity: 'daily',
  }
}
